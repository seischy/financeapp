import React, { useEffect, useMemo, useState } from "react";

export default function App() {
  // ... user code here ...
  return <div>Personal Finance App loaded</div>;
}